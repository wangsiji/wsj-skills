---
name: hermes-dashboard-setup
description: 部署 Hermes Dashboard + nginx反代 + HTTPS + 基本认证。systemd 服务管理、SSL 证书、Host header 兼容。适合普通用户，不含专业术语。
---

# Hermes Dashboard 远程访问配置指南

用 nginx 给 Hermes Dashboard 套上密码保护和 HTTPS 加密，绑定自己的域名，从任何地方用浏览器安全访问。

## 你需要什么

- 一台 VPS（已装好 Hermes Agent）
- 一个域名（比如 `example.com`）
- 基本 Linux 操作能力（会敲命令就行）

## 第一步：启动 Hermes Dashboard

Hermes 自带一个网页版控制面板（Dashboard），默认在 `127.0.0.1:9119` 上运行。

```bash
# 启动
hermes dashboard

# 查看状态
hermes dashboard --status

# 停止
hermes dashboard --stop
```

测试是否启动成功：

```bash
curl http://127.0.0.1:9119/
```

能看到 HTML 返回就算成功。

## 第二步：配置开机自启

⚠️ **不要用 user-level service**（某些 VPS 因 `/etc/nsswitch.conf` 含 `winbind` 导致 status=216/GROUP）。

写一个启动脚本（替换 `你的用户名`）：

```bash
cat > ~/.local/bin/hermes-dashboard.sh << 'EOF'
#!/bin/bash
cd /home/你的用户名
source /home/你的用户名/.hermes/hermes-agent/venv/bin/activate
exec python -m hermes_cli.main dashboard
EOF
chmod +x ~/.local/bin/hermes-dashboard.sh
```

创建 systemd 服务：

```bash
sudo tee /etc/systemd/system/hermes-dashboard.service << 'EOF'
[Unit]
Description=Hermes Agent Dashboard
After=network.target

[Service]
Type=simple
User=你的用户名
ExecStart=/home/你的用户名/.local/bin/hermes-dashboard.sh
WorkingDirectory=/home/你的用户名
Restart=on-failure
RestartSec=10
SupplementaryGroups=

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl enable --now hermes-dashboard.service
```

验证：

```bash
sudo systemctl status hermes-dashboard.service
```

看到 `active (running)` 就对了。

## 第三步：设置域名 DNS

去你的域名管理后台（阿里云/腾讯云/Cloudflare 等），加一条 **A 记录**：

```
你的域名 → 你的 VPS 公网 IP
```

等几分钟让它生效，检查：

```bash
dig +short 你的域名 @8.8.8.8
```

返回你的 VPS IP 就算生效了。

## 第四步：安装工具

```bash
sudo apt-get install -y nginx apache2-utils certbot python3-certbot-nginx
```

## 第五步：设置密码

```bash
sudo htpasswd -c /etc/nginx/.htpasswd 你的用户名
```

## 第六步：写 nginx 配置

```bash
sudo tee /etc/nginx/sites-available/hermes-dashboard << 'EOF'
server {
    server_name 你的域名;

    auth_basic "Hermes Dashboard";
    auth_basic_user_file /etc/nginx/.htpasswd;

    location / {
        proxy_pass http://127.0.0.1:9119;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host "127.0.0.1:9119";  # ⚠️ 必须这样写！dashboard 校验 Host header
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 86400;
    }
}
EOF

sudo ln -sf /etc/nginx/sites-available/hermes-dashboard /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

⚠️ **关键坑**：`proxy_set_header Host` 必须设成 `"127.0.0.1:9119"`，不能传原始域名或 `$host`。Hermes dashboard 内部校验 Host header，传域名会返回 `Invalid Host header`。

## 第七步：配置 HTTPS（免费证书）

```bash
sudo certbot --nginx -d 你的域名 --agree-tos --email 你的邮箱
```

证书 90 天有效，certbot 会自动续期，不用管。

## 第八步：测试

```bash
# 浏览器打开 https://你的域名，输入用户名和密码

# 命令行测试
curl -s -u "用户名:密码" https://你的域名 | head -5
```
不带密码应该返回 401，带密码返回 200 和 HTML 页面。

## 常见问题

| 症状 | 原因 | 解决 |
|------|------|------|
| `status=216/GROUP` | user service NSS 查找失败 | 用 system-level service（装到 `/etc/systemd/system/`） |
| `Invalid Host header` | Host header 传了域名 | 改成 `127.0.0.1:9119` |
| `address already in use` | 重复启动 | 先 `hermes dashboard --stop` |
| 访问 401 | 密码错了 | `sudo htpasswd /etc/nginx/.htpasswd 用户名` 重设 |
| `wangsiji.site` 打不开 / 返回 401 或 502 | Dashboard 服务挂了 | `sudo systemctl status hermes-dashboard` 检查，`sudo systemctl start hermes-dashboard` 重启。如果经常被 kill（如 OOM），检查 `journalctl -u hermes-dashboard --since "24 hours ago"` 看原因 |

### 想改密码

```bash
sudo htpasswd /etc/nginx/.htpasswd 用户名
```

### 想加另一个用户

```bash
sudo htpasswd /etc/nginx/.htpasswd 新用户名
```

注意：不要加 `-c` 参数，否则会覆盖已有的密码文件。

### 手动续期证书

```bash
sudo certbot renew
```
