---
name: syncthing-setup
description: Syncthing 点对点文件同步 — VPS 搭建、多设备配置、端口被封解决方案
category: devops
triggers:
  - "Syncthing"
  - "跨设备同步"
  - "Obsidian 同步"
  - "文件同步到 VPS"
  - "Syncthing 断开连接"
  - "设备 ID"
---

# Syncthing 多设备文件同步

## 场景
在 Mac/iPhone/VPS 之间同步 Obsidian 笔记库（或其他文件夹），任意一端改动，其他端自动同步。
- Mac ↔ iPhone：通过 iCloud 原生同步，不需要 Syncthing 介入
- VPS：通过 Syncthing 增量同步 Mac 本地文件

## VPS 端安装与配置

### 安装（Linux amd64）
```bash
# 下载 Syncthing
cd /tmp
curl -LO https://github.com/syncthing/syncthing/releases/download/v2.0.16/syncthing-linux-amd64-v2.0.16.tar.gz
tar xzf syncthing-linux-amd64-v2.0.16.tar.gz
sudo cp syncthing-linux-amd64-v2.0.16/syncthing /usr/local/bin/
sudo mkdir -p /var/syncthing
sudo chown $USER:$USER /var/syncthing

# 配置自启动（systemd）
cat > ~/.config/systemd/user/syncthing.service << 'EOF'
[Unit]
Description=Syncthing

[Service]
ExecStart=/usr/local/bin/syncthing serve --home=/var/syncthing --no-browser --gui-address=0.0.0.0:8384
Restart=always
User=wangsiji

[Install]
WantedBy=default.target
EOF
systemctl --user daemon-reload
systemctl --user enable --now syncthing
```

### 手动启动（不用 systemd 时）
```bash
mkdir -p /var/syncthing
/usr/local/bin/syncthing serve --home=/var/syncthing --no-browser --gui-address=0.0.0.0:8384
```
- GUI：`http://VPS_IP:8384`
- 数据端口：`22000`
- API Key 位置：`/var/syncthing/config.xml` 的 `<gui>` 标签下 `apikey` 字段

### 端口
- `8384`（TCP）：Web GUI
- `22000`（TCP+QUIC）：Syncthing 数据传输
- `21027`（UDP）：本地发现（局域网内设备发现）

## 已知问题：VPS 端口被封

**症状**：设备状态显示「已断开连接」，VPS 上 Syncthing 进程正常但 Mac 无法连接。

**原因**：很多 VPS 服务商（RackNerd、Vultr 等）默认屏蔽入站 TCP/UDP 22000 端口。

**解决方案**：开启 Global Relay 中继（不依赖直连端口）

1. VPS Web UI → 设置 → 连接 → 勾选「启用全球发现」「启用全球中继服务器」
2. 保存后设备通过公共中继服务器（`relays.syncthing.net`）建立连接，不依赖直连端口

## 手动配置设备（最可靠方法：直接编辑 config.xml）

**坑**：Syncthing v2.0 REST API 端点格式不稳定，`/rest/devices` 经常返回 405/404。直接编辑 config.xml 是最可靠的方式。

### 添加设备
```python
import re

with open('/var/syncthing/config.xml', 'r') as f:
    content = f.read()

device_xml = '''<device id="MAC的设备ID" name="Mac" compression="metadata" introducer="false" skipIntroductionRemovals="false" introducedBy="">
        <address>relay://global</address>
        <paused>false</paused>
        <autoAcceptFolders>true</autoAcceptFolders>
        <maxSendKbps>0</maxSendKbps>
        <maxRecvKbps>0</maxRecvKbps>
    </device>'''

# 在 VPS 自身设备条目之后插入
vps_id = "XTMLFNH-LYUQY2I-XERNZRV-MOYENQA-PTTAM5X-O56DP5F-WSHVBWF-5WMC2AA"  # 替换为实际 VPS 设备 ID
pattern = r'(<device id="' + vps_id + r'"[^>]*>.*?</device>)'
match = re.search(pattern, content, re.DOTALL)
if match:
    insert_pos = match.end()
    new_content = content[:insert_pos] + '\n    ' + device_xml + content[insert_pos:]
    with open('/var/syncthing/config.xml', 'w') as f:
        f.write(new_content)
    print('Device added')
```

### 添加/修改文件夹
```python
content = content.replace('id="dm4tf-trk9a"', 'id="obsidian-vault"')  # 清理旧自动生成的 ID
content = content.replace('path="dm4tf-trk9a"', 'path="/home/wangsiji/syncthing/Obsidian"')
```

### 重启 Syncthing
```bash
# 杀掉旧进程
kill $(ps aux | grep 'syncthing serve' | grep -v grep | awk '{print $2}')
sleep 2

# 启动（用 background=true，不使用 nohup）
/usr/local/bin/syncthing serve --home=/var/syncthing --no-browser --gui-address=0.0.0.0:8384

# 验证
curl -s http://127.0.0.1:8384/rest/system/ping
# 期望：{"ping":"pong"}
```

## Syncthing 故障排查第一检查项

**症状**：Remote Devices 显示 Disconnected，VPS 上 Syncthing Web UI 打不开或 API 无响应。

**第一步永远是检查进程是否在跑**：
```bash
ps aux | grep syncthing | grep -v grep
curl -s http://127.0.0.1:8384/rest/system/ping
```
如果进程不存在（没有输出），先启动：
```bash
/usr/local/bin/syncthing serve --home=/var/syncthing --no-browser --gui-address=0.0.0.0:8384
```
不要先查日志、配置、网络——先确认进程活着。

### 重启 Syncthing（正确方式）

**不要用 nohup/background 混用**，会导致进程跑到 shell wrapper 里被误判。用 terminal 的 `background=true` 参数：

```bash
# 杀掉旧进程
kill $(ps aux | grep 'syncthing serve' | grep -v grep | awk '{print $2}')

# 启动（用 background=true）
/usr/local/bin/syncthing serve --home=/var/syncthing --no-browser --gui-address=0.0.0.0:8384
```

**验证**：
```bash
sleep 3
curl -s http://127.0.0.1:8384/rest/system/ping
# 期望：{"ping":"pong"}
```

---

## 坑：文件夹 ID 必须预先匹配

**症状**：`Failed to auto-accept folder due to path conflict`

**原因**：Mac/iPhone 发送的文件夹邀请带有自动生成的 ID，与 VPS 上配置的不一致。最常见情况是 iPhone Syncthing 自动生成的文件夹 ID 带有空格（如 `   obsidian-vault`），导致 ID 匹配失败。

**排查方法**：
```bash
# 查看 VPS config.xml 中实际配置的文件夹 ID
grep '<folder ' /var/syncthing/config.xml | head -5
# 查看 iPhone 日志中的文件夹 ID
# VPS 日志中会出现：Unexpected folder ID in ClusterConfig
```

**解决方案**：
1. iPhone 上手动修改文件夹 ID：Syncthing → 文件夹 → 编辑 → 文件夹 ID 手动填写为 `obsidian-vault`（不能有空格）
2. 如果已有重复的文件夹配置，先删除再重建
3. 双方都改完后，重启两端 Syncthing

**操作顺序**：
1. **VPS 先配好**文件夹（ID 固定为 `obsidian-vault`，路径指向实际 vault 目录）
2. iPhone 添加文件夹时手动填相同 ID `obsidian-vault`，不要用自动生成的
3. 两边 ID 一致后，等待 relay 握手（10-30 秒）
4. 日志出现 `Established secure connection` + `Ready to synchronize` 即成功

**推荐操作顺序**：
1. Mac 添加 VPS 设备（地址填 `relay://global`）
2. Mac 添加文件夹，ID 填稳定名称如 `obsidian-vault`，路径选 Obsidian 库
3. 同时 VPS 上也用相同 ID 创建文件夹
**修复**：Mac 上点击设备行 → Address 改为 `relay://global`，保存。
- 同时确认 Mac Settings → Connection 里 Global Discovery 和 Global Relay 都已启用
- Relay Server Address 填：`relays.syncthing.net`
- 等待 10-30 秒，状态应变为 Connected

### 坑：VPS config.xml 中重复的文件夹条目

**症状**：Web UI 显示两个 `obsidian-vault` 文件夹，设备状态混乱，同步时断时续。

**原因**：iPhone 自动接受了两次文件夹邀请，在 VPS config.xml 中写入了两个不同的 `<folder>` 条目（一个是带空格的 ID，一个是正常 ID）。这会导致 Syncthing 行为不确定。

**修复**：
```bash
# 查看重复条目
grep -n '<folder ' /var/syncthing/config.xml

# 编辑器打开，手动删除带空格 ID 的重复条目
# 只保留 id="obsidian-vault" 且 path=/home/wangsiji/syncthing/Obsidian/wsj-second-brain 的那个
```

**预防**：iPhone 添加文件夹时手动指定稳定 ID，不要用自动生成的。

### 坑：文件夹路径必须完全一致

### VPS 端（已知设备 ID 和路径）
- 设备 ID：`XTMLFNH-LYUQY2I-XERNZRV-MOYENQA-PTTAM5X-O56DP5F-WSHVBWF-5WMC2AA`
- GUI 端口：`8384`
- 数据端口：`22000`
- 文件夹路径：`/home/wangsiji/syncthing/Obsidian/wsj-second-brain`
- WebDAV 服务器端口：`8385`（用于 iPhone Obsidian 直接连接）

### Mac 端
1. 安装：`brew install syncthing`
2. 启动：`syncthing serve` → Web UI：`http://localhost:8384`
3. 操作菜单 → 添加远程设备 → 输入 VPS 设备 ID → 保存
4. 添加文件夹 → 路径选 Obsidian 库路径 → ID 手动填 `obsidian-vault` → 分享给 VPS

### iPhone 端
1. App Store 下载 **Syncthing** 或 **Syncthing Lite**
2. 同样添加 VPS 设备 → 分享同一文件夹

## 验证

**快速检查脚本**（推荐）：
```bash
bash ~/.hermes/skills/devops/syncthing-setup/scripts/syncthing-status.sh
```

**手动验证**：
```bash
# 检查 Syncthing 进程
ps aux | grep syncthing | grep -v grep

# 检查端口
ss -tlnp | grep -E '8384|22000'

# 测试 API
curl http://127.0.0.1:8384/rest/system/ping \
  -H "X-API-Key: m4HTqYUfEetb7gMjJk7nmeKzhe7Qq9fa"
# 期望：{"ping":"pong"}

# 查看连接状态（从日志）
# 搜索 "Established secure connection" 和 "Joined relay"
```

## 坑：文件夹路径必须完全一致

**症状**：VPS 显示 `folder marker missing`，或设备连接但文件不同步。

**原因**：三方路径结构必须完全一致：
- VPS: `/home/wangsiji/syncthing/Obsidian/wsj-second-brain`
- Mac/iPhone: `~/.../wsj-second-brain`（不能只到 `Obsidian`）

**排查步骤**：
```bash
# 1. 确认 VPS 上实际 vault 路径
ls /home/wangsiji/syncthing/Obsidian/

# 2. 检查 .stfolder 标记文件是否存在（缺失会报 error）
ls /home/wangsiji/syncthing/Obsidian/wsj-second-brain/.stfolder

# 3. 如缺失则创建
mkdir -p /home/wangsiji/syncthing/Obsidian/wsj-second-brain/.stfolder

# 4. 检查同步状态
curl -s http://127.0.0.1:8384/rest/db/status?folder=obsidian-vault \
  -H "X-API-Key: m4HTqYUfEetb7gMjJk7nmeKzhe7Qq9fa" | python3 -c "import sys,json; d=json.load(sys.stdin); print('state:', d['state'], 'need:', d['needTotalItems'])"
```

## iPhone + Obsidian 跨生态同步方案（核心方案）

**问题根源**：iPhone 上 Obsidian vault 在 iCloud 里，Syncthing 是独立 App 访问不了 iCloud 的沙箱目录，所以 Syncthing 指向 iCloud 目录永远无法同步。

**解决架构**：
- Mac ↔ iPhone：iCloud 原生同步（不需要 Syncthing）
- iPhone ↔ VPS：Obsidian 内置 WebDAV 直连 VPS（不需要 Syncthing）

### 第一步：在 VPS 上安装 WsgiDAV（iPhone Obsidian WebDAV 服务器）

```bash
pip install wsgidav cheroot --break-system-packages
```

### 第二步：启动 WebDAV 服务器

```bash
# 端口 8385，指向实际 vault 路径（当前: wsj-second-brain）
wsgidav --host=0.0.0.0 --port=8385 \
  --root=/home/wangsiji/syncthing/Obsidian/wsj-second-brain \
  --auth=anonymous
```

**验证**：
```bash
curl -s -X PROPFIND http://127.0.0.1:8385/ -H "Depth: 1" | head -5
# 应返回 XML，列出目录文件
```

### 第三步：iPhone Obsidian 配置

Obsidian → 设置 → 保险库 → 远程存储 → 添加 → WebDAV：
- 服务器：`http://VPS_IP:8385`
- 用户名/密码：留空（匿名）
- 保险库名：`wsj-second-brain`

### 已知限制
- 当前 WsgiDAV 无认证，建议配合防火墙只允许 iPhone IP 访问
- Syncthing 和 WsgiDAV 共存：Syncthing 同步 `wsj-second-brain` 目录，WsgiDAV 也指向同一目录，两套系统互不干扰

## 坑：Mac/iPhone 的 Obsidian 在 iCloud 里时的同步策略

**不要**让 Syncthing 直接同步 iCloud 目录，否则会与 iCloud 自己的同步冲突。

**正确架构**：
- Mac ↔ iPhone：走 iCloud 原生同步（不需要 Syncthing 介入）
- Mac → VPS：Syncthing 指向本地 vault 副本
- iPhone ↔ VPS：WebDAV（Obsidian 内置功能）

**Mac 上 Syncthing 文件夹路径**：
- ❌ `/Users/wangsiji/Library/Mobile Documents/iCloud~md~obsidian/Documents`（iCloud 目录，会冲突）
- ✅ `/Users/wangsiji/Library/Mobile Documents/iCloud~md~obsidian/Documents/wsj-second-brain`（本地 vault 副本）

**iPhone 上**：vault 路径通常在 Obsidian App 内设置，与 iCloud 同步目录一致即可。

## 参考：noVNC 远程桌面

如果需要在 VPS 上通过浏览器访问图形桌面（用于 iCloud-for-linux 等 GUI 应用），参考 `vps-remote-desktop` 技能。但 Syncthing 同步文件不需要图形界面，纯命令行即可。
