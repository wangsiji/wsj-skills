---
name: obsidian
description: Read, search, and create notes in the Obsidian vault.
---

# Obsidian Vault

**Location:** `/home/wangsiji/projects/wsj-second-brain`

**人生主线结构（固定）：**
- 健康 > 生活 > 价值
- 健康子主线：运动、饮食、睡眠、情绪
- 生活子主线：家庭生活、人际社群、体验突破、休闲娱乐
- 价值子主线：财务理财、工作事业、学习成长

> 注意：体重不是独立子主线，属于运动/饮食。所有 OKR/规划/整理基于上述固定结构。

## Read a note

```bash
VAULT="${OBSIDIAN_VAULT_PATH:-$HOME/Documents/Obsidian Vault}"
cat "$VAULT/Note Name.md"
```

## List notes

```bash
VAULT="${OBSIDIAN_VAULT_PATH:-$HOME/Documents/Obsidian Vault}"

# All notes
find "$VAULT" -name "*.md" -type f

# In a specific folder
ls "$VAULT/Subfolder/"
```

## Search

```bash
VAULT="${OBSIDIAN_VAULT_PATH:-$HOME/Documents/Obsidian Vault}"

# By filename
find "$VAULT" -name "*.md" -iname "*keyword*"

# By content
grep -rli "keyword" "$VAULT" --include="*.md"
```

## Create a note

```bash
VAULT="${OBSIDIAN_VAULT_PATH:-$HOME/Documents/Obsidian Vault}"
cat > "$VAULT/New Note.md" << 'ENDNOTE'
# Title

Content here.
ENDNOTE
```

## Append to a note

```bash
VAULT="${OBSIDIAN_VAULT_PATH:-$HOME/Documents/Obsidian Vault}"
echo "
New content here." >> "$VAULT/Existing Note.md"
```

## Cross-Device Sync（跨设备同步）

### ✅ 跨平台同步方案

**结论：iCloud Drive 在 Linux 上无法挂载。** Apple 没有公开 WebDAV 接口，`icloud.com/icloud-drive` 是 404，davfs2 / pyiCloud / rclone 全部走不通 iCloud 私有 CloudKit 协议。

**推荐方案：Syncthing（真正的三端双向同步）**

```
iPhone ↔ Mac ↔ VPS（Syncthing P2P 网络）
        同一文件夹，任何端改动，其他端秒级同步
```

**已在 VPS 上部署 Syncthing：**
- 设备 ID：`XTMLFNH-LYUQY2I-XERNZRV-MOYENQA-PTTAM5X-O56DP5F-WSHVBWF-5WMC2AA`
- GUI 端口：8384（已监听公网）
- 数据端口：22000（TCP/QUIC）
- 二进制：`/usr/local/bin/syncthing`（v2.0.16）
- 配置目录：`/var/syncthing/`
- API Key：`m4HTqYUfEetb7gMjJk7nmeKzhe7Qq9fa`
- 同步文件夹位置：`/home/wangsiji/projects/wsj-second-brain`

**三端配置：**
1. Mac：安装 Syncthing，添加 VPS 设备 ID，共享文件夹指向 Obsidian 仓库
2. iPhone：App Store 安装 Syncthing，同上
3. VPS：已就绪，无需额外配置

**管理界面**：`http://192.3.16.123:8384`（设备 ID 已预配置，首次访问设密码）

**备选方案：Git 中转**
```
Mac (Obsidian, iCloud) → GitHub → VPS (cron pull)
                              ↘ iPhone (Working Copy)
```
- Mac 上 Obsidian 仓库配 Git，每次编辑自动 push
- VPS 定时 `git pull`
- 适合不想在 Mac 跑 Syncthing 常驻进程的场景

### 快速上手 Git 中转

Mac Obsidian 仓库路径：
```
~/Library/Mobile Documents/iCloud Documents/Obsidian/Documents/<仓库名>/
```

在 Mac 终端初始化 Git（只需一次）：
```bash
cd ~/Library/Mobile\ Documents/iCloud\ Documents/Obsidian/Documents/你的仓库名
git init
git add .
git commit -m "init"
git remote add origin https://github.com/你的用户名/仓库名.git
git branch -M main
git push -u origin main
```

Mac 上装 Obsidian Git 插件（自动 push）或每次手动 `git push`。

服务器定时拉取：
```bash
*/15 * * * * cd ~/你的仓库路径 && git pull --rebase >> ~/.obsidian_sync.log 2>&1
```

### 环境变量配置

```bash
# ~/.bashrc 或 ~/.zshrc
export OBSIDIAN_VAULT_PATH="$HOME/Documents/Obsidian Vault"
```

---

## Wikilinks

Obsidian links notes with `[[Note Name]]` syntax. When creating notes, use these to link related content.
