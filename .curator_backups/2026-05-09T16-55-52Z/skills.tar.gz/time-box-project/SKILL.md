---
name: time-box-project
description: 时间盒项目 — 3篇文章+微信小程序配套交付，文章与小程序功能一一对应
category: productivity
version: 2.0.0
---

# 时间盒项目

## 项目结构
```
/home/wangsiji/projects/time-box/
├── articles/
│   ├── 01-原理篇.md      # 时间盒原理 + 马斯克5分钟块方法论（第一性原理/周日规划）
│   ├── 02-工具演示篇.md  # 小程序使用指南（与小程序功能一一对应，含5分钟块说明）
│   └── 03-补充篇.md      # FAQ + 马斯克进阶用法（周日规划法）+ 延伸阅读《埃隆·马斯克传》
└── miniprogram/          # UniApp + Vue3 + TypeScript
    ├── src/pages/index/index.vue  # 时间盒核心页面
    └── dist/build/mp-weixin/     # 微信开发者工具导入此目录
```

## 小程序功能（已实现，与文章对应）

| 功能 | 说明 |
|------|------|
| 时长选择 | 6个选项：5/15/25/45/60/90 分钟，3×3卡片网格，数字+min+场景描述 |
| 任务名称输入 | 计时器上方可输入任务名（如"写周报"），居中输入框，动态placeholder |
| 标签选择 | 6个：深度工作/学习/带娃/运动/创作/休息（含emoji图标） |
| 环形进度条 | SVG 环形 + 大字剩余时间（mm:ss），空状态有脉动动画 |
| 开始/暂停/继续/停止 | 计时控制，完成计入统计 |
| 完成弹窗 | "🎉 交付完成" + "这就是时间的力量" + "继续下一个 →" |
| 今日统计 | 今日完成次数 + 总分钟数 + 连续天数徽章（橙色渐变背景） |
| 近7天柱状图 | 底部柱状图，今天高亮，自动计算最大值 |
| 首次使用引导 | 蒙层提示，顶部迷你环形计时器预览 + 3条核心技巧 |
| 分享到朋友/朋友圈 | onShareAppMessage / onShareTimeline |
| 关于页面 | 功能介绍 + 使用指南 + 版本信息 |
| 数据持久化 | wx.setStorageSync，重启/切换页面不丢失 |
| 空状态欢迎词 | "今天，准备交付什么？" + "选个时长，现在就开始第一次专注" |
| 连胜徽章 | 橙色渐变背景+阴影，🔥 + 数字，更醒目 |
| tagline文案池 | 6条随机 Motivation 文案 |
| 马斯克深度块提示 | 选60或90分钟时显示紫色渐变提示条 |

**待接入**：微信订阅消息推送（当前为弹窗提醒）

## 调试与排错

### WXML 编译错误（wx:if/wx:else 配对错乱）
**现象**：`Bad attr wx:else with message: wx:if not found`，编译报错但 uni build 成功。

**根因**：Vue 模板中 `v-if`/`v-else` 嵌套方式不对——同一父元素下有两个平行的 `v-if` + 两个 `v-else`，UniApp 编译时会将内层配对搞乱。

**修复原则**：每个 `v-if` / `v-else` 链使用独立的 wrapper 元素，不要在同一个 view 内混合多个独立条件。
```vue
❌ 错误：同一 view 内平行多个 v-if
<view>
  <text v-if="a">X</text>
  <text v-if="a">Y</text>
  <text v-else>Z</text>
</view>

✅ 正确：条件相同的内容包在同一个条件分支内
<view v-if="a"><text>X</text><text>Y</text></view>
<view v-else><text>Z</text></view>
```

**验证**：构建后检查 `dist/build/mp-weixin/pages/index/index.wxml`，用 `grep -c 'wx:if='` / `grep -c 'wx:elif='` / `grep -c 'wx:else'` 确认数量，配对数 = wx:if 总数 >= wx:elif + wx:else。

### 视觉预览工作流（给用户review用）

**问题**：browser_vision 工具无法在对话中内联显示图片给用户看。

**解决方案**：
1. 生成 `preview.html`（小程序静态HTML预览）
2. 用 playwright 截图：`python3 -c "from playwright.sync_api import sync_playwright; ..."`
3. 用 `send_message(action='send', target='telegram:chat_id')` 发送图片到 Telegram

```python
# 截图脚本
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page(viewport={'width': 390, 'height': 844})
    page.goto('file:///home/wangsiji/projects/time-box/preview.html')
    page.wait_for_timeout(1500)
    page.screenshot(path='/home/wangsiji/projects/time-box/preview.png', full_page=True)
    browser.close()
```

**Telegram chat_id**：`7128007362`（wang siji）

### 微信开发者工具缓存问题
**现象**：WXML 源码已修复，uni build 成功，但真机调试仍报同样的错。

**处理**：微信开发者工具会缓存旧的编译产物。
1. **完全删除** `dist/build/mp-weixin/` 目录（不是清空，是删掉整个目录）
2. 重新 `uni build -p mp-weixin`
3. 微信开发者工具里点**完全重新编译**（不是热重载）

### 常见信号
| 信号 | 可能原因 |
|------|---------|
| uni build 成功但 DevTools 报错 | 缓存旧产物 或 WXML 配对问题 |
| 页面空白/数据不更新 | `onMounted` 未触发或 storage key 不一致 |
| 计时器不走 | `setInterval` 被意外清除 |

## 小程序构建命令
```bash
cd /home/wangsiji/projects/time-box/miniprogram
node_modules/.bin/uni build -p mp-weixin
# 输出：dist/build/mp-weixin/  → 微信开发者工具导入此目录
```
> 前台运行即可（timeout 180s足够），构建成功后 exit_code=0，DONE Build complete

## 文章与工具对应关系
- **01-原理篇**：教育内容，无需工具截图
- **02-工具演示篇**：3步上手（选时长→选标签→点开始）+ FAQ + 底部7天柱状图
- **03-补充篇**：工具地址「微信搜索时间盒小程序」

文章内部链接已修复（相对路径）。

## 发布时间节奏
1. **01-原理篇** → 发布
2. **02-工具演示篇** → 发布（附小程序码/搜索「时间盒」）
3. **03-补充篇** → 发布

## 部署状态
- [x] 小程序功能升级（5分钟块/任务名/马斯克深度块提示）
- [x] 小程序UI优化（脉动动画/连胜徽章/完成弹窗/引导弹窗）
- [x] 3篇文章升级（引入马斯克方法论，与新UI完全对应）
- [x] 构建成功 dist/build/mp-weixin/
- [ ] 小程序正式提交微信审核（需 AppID）
- [ ] 文章内链接替换为实际小程序码
- [ ] 微信通知功能接入（订阅消息）

## 用户 Profile（参考）
- 北航软件学院人工智能专业硕士，算法工程师背景
- 2025年5月百度离职，目前大理旅居，有车有娃
- 400万存款 + 老婆自媒体收入~1万/月
- 老婆公众号"秋秋很开心"有大号（~100万粉丝，2年前停更）
- 内容分工：他在老婆账号写学习方法和实用工具类内容，老婆改稿发布
- 工作风格：给任务希望我直接完成，他来润色 review，不喜欢反复讨论
