---
name: web-search-workaround
description: 网络搜索受限时（Google/Bing/DuckDuckGo被屏蔽）的替代方案。服务器IP被主流搜索引擎屏蔽时，使用 Wikipedia API、GitHub API 和直接内容站点抓取。
category: research
---

# Web Search Workaround

当常规搜索引擎（Google/Bing/DuckDuckGo）被服务器IP屏蔽时，使用以下可用的替代方案。

## 可用方案（按优先级）

### 1. Wikipedia API（最稳定）
```bash
# 搜索词条
curl "https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=关键词&format=json&limit=10"

# 获取页面内容（纯文本）
curl "https://en.wikipedia.org/w/api.php?action=query&pageids=PAGEID&prop=extracts&explaintext&format=json"

# 获取页面链接结构
curl "https://en.wikipedia.org/w/api.php?action=query&titles=PAGENAME&prop=links&format=json"
```

### 2. GitHub API（适合技术/项目类内容）
```bash
# 搜索仓库
curl "https://api.github.com/search/repositories?q=关键词&sort=stars&per_page=5"

# 搜索代码
curl "https://api.github.com/search/code?q=filename:关键词&per_page=5"
```

### 3. 直接内容站点（需加 User-Agent）
```bash
# 健康/科学类网站（可用）
curl -A "Mozilla/5.0" "https://www.healthline.com/..."

# 以下站点测试可用：
# - healthline.com (200)
# - mayoclinic.org (200)
# - britannica.com (200)
# - runnersconnect.net (200)
# - runnersworld.com (200)
# - nike.com (200)
```

### 4. 已知不可用（已验证）
- `duckduckgo.com` / `html.duckduckgo.com` — DuckCAPTCHA 验证码
- `google.com` — DNS 解析失败（ERR_NAME_NOT_RESOLVED）
- `bing.com` — Cloudflare JavaScript 挑战页
- `baidu.com` — 超时
- `zhihu.com` — 需要 JS 渲染
- `searx.be` — 403 Forbidden
- `startpage.com` — Captcha

## 诊断脚本
```bash
# 快速检测哪些方案可用
for url in \
  "https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=test&format=json" \
  "https://api.github.com/search/repositories?q=test" \
  "https://www.healthline.com"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "$url")
  echo "$code $url"
done
```

## 搜索策略
1. 先用 Wikipedia API 搜概念/方法论
2. 用 GitHub 搜开源训练计划/项目
3. 目标站点直接抓取（加 `-A "Mozilla/5.0"`）
4. 内容需 JS 渲染时 → 建议用户直接发链接，用 browser 工具读取
