---
name: github-repo-type
description: 快速判断一个 GitHub 仓库应该怎么安装/集成到 Hermes——是 Hermes skill、CLI 工具、还是 MCP server。避免把独立项目误当成 Hermes skill 安装。
version: 1.0.0
author: Hermes Agent
tags: [hermes, skills, mcp, github, installation]
---

# GitHub 仓库类型判断

## 三种类型

| 类型 | 安装方式 | 判断依据 |
|------|---------|---------|
| **Hermes Skill** | `hermes skills install <id>` | 仓库里有 `SKILL.md`，且发布在 Skills Hub |
| **CLI 工具** | `git clone` + `pip install` / `pip install -e .` | 有 `pyproject.toml`/`setup.py`，但没有 `SKILL.md` |
| **MCP Server** | `git clone` + 配置到 `config.yaml` 的 `mcp` 段落 | 仓库名含 `mcp`，或 README 描述为"MCP server" |

## 判断流程

1. 打开 GitHub 仓库首页
2. 看仓库根目录有没有 **`SKILL.md`** → 如果有，可能是 Hermes skill（需确认是否在 Skills Hub 发布过）
3. 看有没有 **`pyproject.toml`** 或 **`setup.py`** → CLI 工具
4. 看 README 是否描述为 **"MCP server"** 或仓库名含 `mcp` → MCP server
5. 以上都没有 → 可能是普通代码库，需要手动分析

## 实际操作命令

### 安装 CLI 工具
```bash
git clone https://github.com/用户名/仓库名.git
cd 仓库名
pip install -e .   # 开发模式
# 或
pip install .       # 生产模式
```

### 安装 MCP Server
```bash
git clone https://github.com/用户名/仓库名.git
# 然后用 hermes mcp add 配置
hermes mcp add <name> --command "python" --args "path/to/server.py"
```

### 安装 Hermes Skill
```bash
hermes skills install <skill-id>
# 或从 GitHub 安装（如果支持）
hermes skills tap add https://github.com/用户名/仓库名
```

## 常见误区

- ❌ 以为所有好东西都能 `hermes skills install`
- ❌ 以为 GitHub 项目都有 `SKILL.md`
- ❌ 混淆"MCP server"和"Hermes skill"——两者完全不同

## 快速验证

安装完后，确认是否成功：
```bash
# CLI 工具
<命令名> --help

# MCP server
hermes mcp list

# Hermes skill
hermes skills list
```

## 关键判断问题

遇到用户想安装 GitHub 上的项目时，先问自己：
1. 仓库有 `SKILL.md` 吗？→ 可能是 Hermes skill
2. 仓库是 `mcp` 相关吗？→ MCP server
3. 仓库有 `pyproject.toml` 吗？→ CLI 工具
4. 都不符合 → 普通代码，需要单独分析
