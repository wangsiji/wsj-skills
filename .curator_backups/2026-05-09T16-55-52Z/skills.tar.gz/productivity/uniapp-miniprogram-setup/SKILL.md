---
name: uniapp-miniprogram-setup
description: UniApp 开发微信小程序项目搭建
---

# UniApp 开发微信小程序项目搭建

## 适用场景
从零开始搭建 UniApp + Vue3 项目，输出微信小程序。

## 项目初始化步骤

### 1. 创建项目目录
```bash
mkdir -p miniprogram/src/{pages/index,components,utils}
```

### 2. package.json
```json
{
  "name": "xxx-mini",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev:mp-weixin": "uni -p mp-weixin",
    "build:mp-weixin": "uni build -p mp-weixin"
  },
  "dependencies": {
    "@dcloudio/uni-app": "3.0.0-xxx",
    "vue": "^3.4.21",
    "pinia": "^2.1.7"
  },
  "devDependencies": {
    "@dcloudio/vite-plugin-uni": "3.0.0-xxx",
    "@dcloudio/types": "^3.4.8",
    "vite": "^5.2.8",
    "sass": "^1.77.0"
  }
}
```

### 3. vite.config.ts
```ts
import { defineConfig } from 'vite'
import uni from '@dcloudio/vite-plugin-uni'

export default defineConfig({
  plugins: [uni()]
})
```

### 4. 核心文件
- `src/main.ts` — SSR App 入口
- `src/App.vue` — 根组件
- `src/pages.json` — 页面路由配置
- `src/manifest.json` — App/小程序配置（**AppID 在这里改**）
- `src/pages/index/index.vue` — 首页

### 5. 安装依赖
```bash
npm install
# 可能有很多 deprecated 警告，不用管
```

### 6. 构建微信小程序
⚠️ **关键**：`npm run dev:mp-weixin` 会尝试在前台运行导致超时，必须用 background 模式：

```bash
# 构建（后台运行）
node_modules/.bin/uni build -p mp-weixin > /tmp/uni_build.log 2>&1
cat /tmp/uni_build.log
```

### 7. 微信开发者工具导入
1. 下载微信开发者工具：https://developers.weixin.qq.com/miniprogram/dev/devtools/download.html
2. 导入目录：`dist/build/mp-weixin`
3. AppID 在 `src/manifest.json` → `mp-weixin.appid` 替换

## 常见问题

### npm install peer dependency warnings
不用管，依赖装上了就行

### vite build 前台模式报错
必须用后台模式，不能直接前台运行：
```bash
node_modules/.bin/uni build -p mp-weixin > /tmp/uni_build.log 2>&1 &
```
查看日志：`tail -f /tmp/uni_build.log`

### 编译报 "Unexpected token" 但代码看起来没问题
通常是 Vue 模板里有多余的 `}` 或语法错误，错误指向的行号不准确。从可疑的函数（如 `sendNotify`）开始逐段注释排查。

### 小程序不显示内容
检查 `src/pages.json` 的 `globalStyle.navigationStyle` 是否设为 `custom`，如果是需要手动隐藏原生导航栏：
```ts
uni.hideHomeButton({})
```

## 项目结构示例
```
miniprogram/
├── package.json
├── vite.config.ts
├── README.md
├── src/
│   ├── main.ts
│   ├── App.vue
│   ├── manifest.json
│   ├── pages.json
│   └── pages/
│       └── index/
│           └── index.vue
└── dist/
    └── build/
        └── mp-weixin/  ← 微信开发者工具导入此目录
```

## 依赖版本（2026-04 实测可用）
- uni-app: `3.0.0-4060620250520001`
- vue: `^3.4.21`
- pinia: `^2.1.7`
- vite: `^5.2.8`
- sass: `^1.77.0`
