---
name: running-coach
description: 跑步教练 — 统一入口：COROS 数据获取 + 每日训练反馈 + 阶段性计划。服务于马拉松破3目标。
---

# Running Coach — 跑步教练

统一入口，整合了：
- **数据获取**：COROS 手表活动抓取
- **训练分析**：基于运动科学的训练评估
- **教练反馈**：每日训练日报 + 明日建议

---

## 用户档案（统一数据源，不要分散）

| 字段 | 值 |
|------|-----|
| 目标 | 2026年12月 马拉松破3（配速 4'15"/km） |
| 当前水平 | 10km 50min / 20km 1:44 → VDOT ≈ 46 |
| 目标 VDOT | 52（对应马拉松 2:59） |
| LTHR | 173 bpm |
| Max HR | 191 bpm |
| 静息心率 | 51 bpm |
| 体重 | 71 kg |
| 身高 | 177 cm |
| 设备 | COROS PACE 3 |
| 时间约束 | 每天 8:20 前完成跑步 |

**COROS 账号**：`wangsiji@buaa.edu.cn` / `1993wang123704`

---

## 心率训练分区（LTHR 173 bpm）

| 区域 | 名称 | 心率范围 | 配速体感 |
|------|------|---------|---------|
| E | 轻松跑 | 129–142 bpm（74–82% LTHR）| 可以说话 |
| M | 马拉松配速 | 155–163 bpm（90–94% LTHR）| 稍吃力 |
| T | 乳酸阈值 | 163–168 bpm（94–97% LTHR）| 吃力但稳定 |
| A | 亚索 | 169–173 bpm（98–100% LTHR）| 接近极限 |
| I | 间歇 | 174–185 bpm（101–107% LTHR）| 非常吃力 |
| R | 冲刺 | > 185 bpm | 最大努力 |

---

## 核心训练原则

### 极化训练（80/20）
- 80% 训练量在 E 区
- 20% 在 T/I/R 区
- M 区不作为日常训练区

### 10% 规则
- 每周跑量增幅不超过 10%
- 连续两周增负荷后需一周减量

### 48小时恢复原则
- 高强度训练后至少48小时才能再次高强度
- ST 次日不能跑阈值，阈值次日不能跑 ST

### 连续高强度禁止
- ST 和 T/LT 不能连续两天
- 长跑（>16km）次日必须休息

### 每周高强度上限：2次

---

## 周期训练阶段

```
基础期   5月–6月   有氧基础      周量 45–65km   E跑+1次短ST
建设期   7月–8月   阈值+速度     周量 65–85km   LT+ST+长E
巅峰期   9月–11月  马拉松配速专项 周量 85–105km  M配速长跑+I/LT维持
减量期   12月      恢复+状态调动 周量 50–70km   轻量M跑+休息
```

---

## 里程碑体系

| 里程碑 | 截止 | 任务 | 目标 |
|--------|------|------|------|
| M1 | 5月底 | 10km 测试 | < 48'00"（VDOT≥47） |
| M2 | 7月底 | 12km 阈值测试 | 均速 < 4'50"/km |
| M3 | 8月底 | 半马比赛 | < 1:38'00" |
| M4 | 10月中 | 30km @ 4'15"不掉速 | 掉速 ≤ 12秒/km |
| M5 | 11月底 | 赛前 30km 模拟 | 掉速 < 15秒/km |

---

## 每日训练反馈模板

```
🏃 教练日报 | {日期} {星期}
🌙 昨日睡眠：{睡眠时长}（目标 ≥ 7h）⚠️ 数据来源不可靠，待验证

━━━━━━━━━━━━━━━━━━━━━━
🎯 里程碑进度：{当前里程碑名称}
   目标：{具体目标值}
   截止：{日期}（还剩X天 / 已完成）
   当前状态：{达标/进行中/落后}
━━━━━━━━━━━━━━━━━━━━━━

【今日训练】
- {运动名称}
- 距离：{X} km | 配速：{X'XX"} | 平均心率：{X} bpm
- 训练负荷：{TL}

📊 本周数据（Mon–Sun）
- 累计跑量：{X} km / {X}次
- 累计负荷：TL {X}
- 较上周（Xkm）：{+/-X%} {↑/↓}

💬 训练点评
{客观数据点评}

📅 明日建议（{星期}·{类型}）
{具体训练内容和理由}
```

---

## 明日建议规则（强制）

1. **今日有 ST** → 明日必须休息或极轻 E 跑（≤30min）
2. **今日有 T/LT** → 明日休息或 30min 极轻松 E 跑
3. **今日长跑 >16km** → 明日必须休息
4. **连续两天高强度** → 绝对禁止
5. **每周高强度 >2次** → 不允许
6. **每周休息日** → 至少 1–2 天完全休息

---

## 数据获取

> **COROS API 详细文档**：`references/coros-api.md`（含睡眠接口、认证方式、已知陷阱）

**两个脚本并存，注意区分：**
- `/home/wangsiji/projects/running-page/sync_coros.py` — 项目目录，较慢，60s 内常超时
- `/home/wangsiji/.hermes/skills/productivity/running-coach/scripts/running_coach.py` — skills 目录，登录跳转处理正确，更可靠

**优先使用 skills 目录的脚本。**

```python
import sys
sys.path.insert(0, '/home/wangsiji/.hermes/skills/productivity/running-coach/scripts')
from running_coach import fetch_activities
from datetime import datetime, timedelta
date_to = datetime.now().strftime('%Y-%m-%d')
date_from = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
acts = fetch_activities(date_from, date_to, headless=True)
```

### 睡眠数据 ⚠️

**已知问题**：COROS `dashboard/queryCycleRecord` API 返回的睡眠数据是缓存值，91天历史数据完全相同，不可用于趋势追踪。type=16 不是总睡眠时长，App 显示值与任何单一 type 字段都无法匹配。详见 `references/coros-api.md`。

**当前状态**：sleep.json 数据不可靠（API返回缓存值，91天完全相同），需用户配合截图 COROS App 睡眠详情页验证字段含义。**让用户直接口述/打字数值**，vision 工具响应不稳定。

**数据文件**：`/home/wangsiji/projects/running-page/data/sleep.json`（字段：date, sleep_sec, sleep_str, types）

```bash
# 拉取全量活动+睡眠数据
cd /home/wangsiji/projects/running-page && python3 sync_coros.py

# 仅拉睡眠数据（跳过跑步）
python3 sync_coros.py --sleep-only
```

输出文件：`/home/wangsiji/projects/running-page/data/activities.json`

**数据字段**：`id`, `date`（YYYYMMDD）, `display_date`（YYYY-MM-DD）, `sport`, `dist_km`, `pace_sec`, `pace_str`, `duration_sec`, `duration_str`, `hr_avg`, `hr_zone`（E/M/T/A/I）, `tl`

**近7天数据读取示例**：
```python
import json
from datetime import datetime, timedelta

with open('/home/wangsiji/projects/running-page/data/activities.json') as f:
    data = json.load(f)

today = datetime(2026, 5, 2)
cutoff = today - timedelta(days=7)
recent = [a for a in data if datetime.strptime(a['date'], '%Y%m%d') >= cutoff]
recent.sort(key=lambda x: x['date'], reverse=True)
```

**备用缓存数据**：`/home/wangsiji/.hermes/coros-cache/YYYY-MM-DD.json`（每日抓取缓存）

### 数据获取：使用 skill 内的 `running_coach.py`（不是 `sync_coros.py`）

**⚠️ 已知问题**：`sync_coros.py`（在 `projects/running-page/` 下）登录后等待 redirect 会超时（约60s），COROS 页面加载慢导致流程挂住。

**正确方式**：使用 skill 内置的 `scripts/running_coach.py`，它在 Playwright 内通过 `page.evaluate` + captured token 直接调 COROS API，全流程约55秒稳定完成。

```bash
cd /home/wangsiji/projects/running-page && python3 /home/wangsiji/.hermes/skills/productivity/running-coach/scripts/running_coach.py --days 7 --output /tmp/running_today.json
```

**日报生成前必做**（更新数据后生成）：
```bash
python3 /home/wangsiji/.hermes/skills/productivity/running-coach/scripts/running_coach.py --days 7 --daily-report
```

输出 `activities.json` 数据文件路径：`/home/wangsiji/projects/running-page/data/activities.json`（备用缓存 `~/.hermes/coros-cache/YYYY-MM-DD.json`）

sleep.json 数据不可靠（见上节），以用户口述为准。

### 雨天训练注意事项

用户提到"最近一直在下雨"。雨天跑步注意事项：
- 路面湿滑 → 降低配速 10-20 秒/km
- 鞋子排水 → 穿排水性好的鞋，避免棉质袜
- 视距缩短 → 穿亮色/反光装备
- 心率可能偏低 → 以体感为准，不强求配速
- 感冒风险 → 及时擦干换衣

日报模板可加一行：`🌧️ 今日天气：雨天（注意防滑、及时换衣）`
然后读取 `data/yearly/2026/summary.json` 的 `recent` 字段取第一条作为今日训练。

### 输出格式

```json
{
  "fetched_at": "2026-04-30T10:46:13",
  "date_from": "2026-04-24",
  "date_to": "2026-04-30",
  "count": 7,
  "activities": [
    {
      "date": "今天",
      "sport": "8k轻松跑+6ST",
      "dist": "10.58km",
      "dist_km": 10.58,
      "duration": "01:03:56",
      "pace": "06'00\"",
      "pace_sec": 360,
      "hr": 149,
      "hr_zone": "M区",
      "tl": 117
    }
  ]
}
```

---

## Cron 自动化

每日早上 8:20 自动推送训练日报：

```
cron job: daily-running-report
时间: 20 8 * * *
deliver: origin
skills: running-coach
```

**⚠️ 数据时效性：日报生成前必须重新拉取数据**

COROS 登录偶尔很慢（可达 40–50 秒），60s 内可能超时。如报告数据不全，多试一次即可。

**日报生成前必做**：
```python
import sys
sys.path.insert(0, '/home/wangsiji/.hermes/skills/productivity/running-coach/scripts')
from running_coach import fetch_activities
from datetime import datetime, timedelta
date_to = datetime.now().strftime('%Y-%m-%d')
date_from = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
acts = fetch_activities(date_from, date_to, headless=True)
```

任务 prompt 核心逻辑：
1. 调用 `running_coach.py` 的 `fetch_activities` 获取最近7天数据
2. 分析今日训练（最近一条）
3. 按模板生成日报
4. 根据训练类型 + 48h规则给出明日建议
5. 标注当前里程碑进度

