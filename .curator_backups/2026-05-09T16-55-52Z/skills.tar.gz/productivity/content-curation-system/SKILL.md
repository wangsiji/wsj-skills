---
name: content-curation-system
description: 跨平台内容精选系统 — Twitter/公众号/RSS → 规则过滤 → LLM 评分 → Telegram digest
---

# Content Curation System — 信息精选系统

## Problem
跨平台（Twitter、公众号、B站、播客）内容过载，需要从噪声中识别真正有价值的内容。

## Architecture Pattern（调研 GitHub 现有方案得出的最佳实践）

```
采集层（RSS / API / 工具）
    ↓
规则预过滤（点赞数阈值、关键词、时间窗口）→ 降低 LLM 调用量
    ↓
LLM 双维度评分（内容质量 × 与我的相关性）
    ↓
Rank + 去重（SQLite/JSON 记录已推送）
    ↓
Digest 输出（Telegram / Newsletter / Obsidian）
```

### 关键 insight
- **规则预过滤是必须的**——不加这层，LLM 成本会爆炸（Twitter 一小时就能刷出几百条）
- Cartero（76 ⭐ Go 项目）的做法：分数阈值 + 关键词过滤 → 剩 10-20 条再 LLM 处理
- DevDigestAI / ailert：RSS 采集 → LLM summarization → email digest

## 已有的采集工具

| 平台 | 工具 | 命令 |
|------|------|------|
| 推特 | xreach | `xreach home --format json` / `xreach list-tweets <url>` |
| 公众号 | wechat-article-for-ai | `python3 ~/.agent-reach/tools/wechat-article-for-ai/main.py <url>` |
| RSS | feedparser | `pip install feedparser` |

## 采集工具坑

- **wechat-article-for-ai 的 BS4 4.14.3 兼容 bug**：soup.new_tag() 在 lxml 解析器下返回 None，修法是建一个独立 BS("", "html.parser") 实例来 new_tag
- **xreach JSON 格式**：
  - 响应结构是 `{"items": [...]}`，不是直接数组，解析用 `data.get('items', [])`
  - 字段名：点赞用 `likeCount`（不是 `favorite_count`），作者用 `screenName`（不是 `screen_name`）
  - Tweet URL 构造：`https://x.com/{screenName}/status/{id}`
- **xreach cookie 认证**：需要先 `xreach auth` 配置 Cookie 才能抓数据

## LLM 配置（MiniMax）

MiniMax API 兼容 OpenAI 格式，但 endpoint 不同：

```python
url = "https://api.minimaxi.com/anthropic/v1/messages"  # 而非 api.openai.com
model = "MiniMax-M2.7"  # 或 MiniMax-M2.5
```

MiniMax API Key 从 `~/.hermes/.env` 里的 `MINIMAX_CN_API_KEY` 获取（key 被 `***` 遮住，需要用户手动提供）。

## 调研发现的参考项目

| 项目 | 技术栈 | 亮点 |
|------|--------|------|
| [cartero](https://github.com/dracarys18/cartero) | Go + SQLite | 配置驱动，RSS/HN/Lobsters → Discord/Feed，支持多目标 |
| [ailert](https://github.com/anuj0456/ailert) | Python + Flask + DynamoDB | 150+ 源，async 处理，newsletter 生成，Section 概念 |
| DevDigestAI | LLM + RSS | GitHub Actions 定时任务，开发者新闻聚合 |

## 输出形态
- Telegram digest（最轻量）
- Obsidian 存档（方便后续检索）
- 或者两者都要

## 行动指引
1. 先用 xreach 验证推特采集 + 规则过滤走通
2. 搭 SQLite 去重表（hash of url，避免重复推送）
3. 规则过滤层：min_likes=10，关键词白名单
4. LLM 评分用双维度 prompt：质量 + 相关性
5. 定时 cron → Telegram 推送
