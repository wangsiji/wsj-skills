# 微信文章列表 API 参考

> 更新：2026-05-03 实测确认

## 五种方案对比（Grok 总结来源）

| # | 方案 | 成本 | 自动化 | 推荐度 |
|---|------|------|--------|--------|
| 1 | 淘宝代采集 | 2.99元/号 | 躺平 | ⭐⭐⭐ |
| 2 | changfengbox 开源工具 | 免费 | 30分钟可视化 | ⭐⭐⭐ |
| 3 | 微信读书官方渠道 | 免费 | 2小时 | ⭐⭐⭐ |
| 4 | wxrank API | 2分/篇 | API调用 | ⭐⭐⭐⭐ |
| 5 | mitmproxy 抓 key + 逆向 API | 免费 | 可自动化 | ⭐⭐⭐（Android可用，iOS不行） |

## 文章列表接口

```
GET https://mp.weixin.qq.com/mp/profile_ext
  ?action=getmsg
  &__biz={biz}
  &f=json
  &offset=0
  &count=10
  &is_ok=1
  &appmsg_token={token}
  &x5=0
  &pass_ticket={pass_ticket}
```

### 必需参数

| 参数 | 来源 | 说明 |
|------|------|------|
| `__biz` | 文章页源码或分享链接 | 公众号唯一标识，base64 编码 |
| `appmsg_token` | mitmproxy 拦截 | 动态 token，有时效 |
| `pass_ticket` | mitmproxy 拦截 | 登录态 ticket |
| `offset` | 分页偏移 | 每次 +10 |
| `count` | 每页数量 | 通常 10 |

### 从单篇文章 URL 提取 `__biz`

文章 URL 格式：`https://mp.weixin.qq.com/s/xxxxx?__biz=xxx&balabala`

`__biz` 是 base64 编码的公众号 ID，解码后可得 appid。

### 响应格式

```json
{
  "ret": 0,
  "errmsg": "ok",
  "msg_list": [
    {
      "comm_msg_info": {
        "id": 100001234,
        "type": 1,
        "datetime": 1704067200,
        "fakeid": "..."
      },
      "app_msg_ext_info": {
        "title": "文章标题",
        "digest": "摘要",
        "content_url": "//mp.weixin.qq.com/s/xxxxx",
        "cover": "https://...",
        "author": "作者",
        "copyright_stat": 100
      }
    }
  ],
  "app_msg_cnt": 533
}
```

其中 `app_msg_cnt` 是总文章数，`content_url` 是文章链接（需补前缀 `https:`）。

## 实测记录（2026-05-03）

**✅ wechat-article-for-ai 验证成功：**
- 命令：`python3 ~/.agent-reach/tools/wechat-article-for-ai/main.py "<url>"`
- 结果：成功下载《从瞎忙到高效！有钱人都在用的时间管理法》by 秋秋很开心
- 输出：`~/.agent-reach/tools/wechat-article-for-ai/output/从瞎忙到高效！有钱人都在用的时间管理法/从瞎忙到高效！有钱人都在用的时间管理法.md`

**❌ API 无 token 实测响应：**
```
GET https://mp.weixin.qq.com/mp/profile_ext?action=home&__biz=xxx&f=json&offset=0&count=5
→ HTTP 200
→ {"ret":-3,"errmsg":"no session","cookie_count":0}
```
**结论：必须获取有效登录态 token，纯服务器端无法绕过。**

**✅ 有效流程：**
1. 用户从微信分享一篇文章链接（右上角三个点 → 复制链接）
2. 从链接提取 `__biz`（例：`__biz=MzI4NzU3ODk5NQ==`，对应公众号ID）
3. 获取有效 `appmsg_token` + `pass_ticket`（需 Android+mitmproxy，或 wxrank API，或公众平台后台）
4. 用脚本循环请求列表 API（offset 0, 10, 20... 直到取完）
5. 用 wechat-article-for-ai 下载每篇文章正文

## 采集流程

1. **最佳路径**：用户登录 mp.weixin.qq.com 后台导出文章列表（无需任何技术操作）
2. **备选**：wxrank API 按公众号批量导出（2分/篇）
3. **技术路径**：mitmproxy 拦截 token → 脚本批量拉列表 → wechat-article-for-ai 下载正文
4. **iOS 用户注意**：微信有 Certificate Pinning，mitmproxy 方案仅 Android 可用
