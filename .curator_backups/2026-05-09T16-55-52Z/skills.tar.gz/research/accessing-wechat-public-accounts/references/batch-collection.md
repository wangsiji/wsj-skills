# 微信公众号全量采集方案

## 实测有效流程（2026-05-03）

**目标**：下载「秋秋很开心」全部历史文章

**已确认公众号 ID**：`__biz=MzI4NzU3ODk5NQ==`

---

## Step 1：获取文章链接列表

### 方案 A：微信公众平台后台（零技术，推荐）
- 登录 `mp.weixin.qq.com`
- 内容与互动 → 群发 → 导出文章列表
- 直接导出 Excel/CSV，包含所有文章标题、链接、发布时间
- **需要公众号管理员权限**

### 方案 B：wxrank API（2分/篇）
- 第三方付费 API，批量导出公众号文章 URL
- 无需自部署，直接调用

### 方案 C：mitmproxy 拦截 token（iOS 不可行）
- 脚本位置：`/home/wangsiji/projects/wechat-scrape/wechat_intercept.py`
- 启动命令：`mitmdump -s /home/wangsiji/projects/wechat-scrape/wechat_intercept.py -p 8888`
- 服务器 IP：`192.3.16.123`
- **⚠️ iOS 微信有证书固定，无法拦截 TLS 流量**
- **Android 可行**

### 方案 D：纯服务器端（不可行）
- 文章列表 API 需要微信登录态 cookie
- 无 token 请求返回 `ret:-3, no session`（已实测）
- 必须有真实微信客户端配合

---

## Step 2：批量下载正文

拿到 URL 列表后：

```bash
python3 ~/.agent-reach/tools/wechat-article-for-ai/main.py -f urls.txt -o ./output -v
```

**注意**：批量处理建议分批执行，每次不超过 10 篇，避免触发反爬。

---

## 文章列表 API 参考

**实测确认**：`https://mp.weixin.qq.com/mp/profile_ext` 需要有效登录态

请求参数：
- `__biz`：公众号 ID（base64 编码）
- `offset`：分页偏移
- `count`：每页数量
- `appmsg_token`：登录态 token（必需）
- `pass_ticket`：登录态 ticket（必需）

无 token 响应：
```json
{"base_resp":{"ret":-3,"errmsg":"no session","cookie_count":0},"ret":-3,"errmsg":"no session"}
```

---

## wechat-article-for-ai 实测记录（2026-05-03）

✅ 单篇下载成功：
```
python3 main.py "https://mp.weixin.qq.com/s/..."
→ 保存至 output/<标题>/<标题>.md
→ 图片自动下载到同目录
```

⚠️ 批量容易超时，务必分批单篇执行
⚠️ 工具需要 Camoufox（stealth Firefox），首次需扫码授权
