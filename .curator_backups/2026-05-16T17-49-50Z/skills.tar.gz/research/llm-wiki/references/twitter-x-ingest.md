# Twitter/X Ingest via xreach

## Tool

```bash
~/.npm-global/bin/xreach tweet "<tweet_id>"
```

Returns JSON with fields:
- `id`, `text`, `createdAt`
- `user.name`, `user.screenName`, `user.profileImageUrl`
- `viewCount`, `likeCount`, `retweetCount`, `replyCount`, `quoteCount`, `bookmarkCount`
- `media[].type`, `media[].url`, `media[].width`, `media[].height`
- `lang`, `isRetweet`, `isQuote`, `isReply`

## Tweet ID Extraction

From URL `https://x.com/<handle>/status/<tweet_id>` — the tweet ID is the last path segment.

From tweet JSON `id` field — this is the numeric tweet ID as a string.

## Filename Convention

```
raw/tweets/<screenName>-<tweetId>.md
```

Examples from this session:
- `raw/tweets/lidangzzz-2044673430901936512.md`
- `raw/tweets/pmbackttfuture-2050036759115833587.md`

## Raw Frontmatter Template for Tweets

```yaml
---
source_url: https://x.com/<handle>/status/<tweetId>
ingested: YYYY-MM-DD
author: <user.name>
username: <user.screenName>
platform: Twitter/X
---
```

## Content Notes

- Link-only tweets (`"https://t.co/..."` as text) mean the actual content is in the
  linked image/page. The tweet metadata is still worth saving; flag content as pending.
- `lang: "zxx"` means language could not be detected — manual review may be needed.
- High `bookmarkCount` relative to `likeCount` suggests the content is especially
  worth filing (people bookmark for later reference more intentionally than they like).

## Additional xreach Commands

```bash
# Get following list for a user
~/.npm-global/bin/xreach following <handle>

# Get user profile
~/.npm-global/bin/xreach user <handle>
```

**`following` response structure:**
```json
{
  "items": [
    {
      "name": "User Name",
      "screenName": "handle",
      "description": "bio text",
      "followersCount": 12345,
      "followingCount": 99,
      "tweetCount": 999,
      "verified": false,
      "isBlueVerified": true,
      "protected": false,
      "location": "City",
      "url": "https://..."
    }
  ]
}
```

**Parsing pattern (Python):**
```python
import json
data = json.load(sys.stdin)
for u in data.get('items', []):
    print(f"@{u['screenName']} | {u['name']} | followers:{u['followersCount']} | {u.get('description','')[:80]}")
```

**Key fields:** `screenName` (handle), `followersCount`, `description`. Profile URL: `https://x.com/{screenName}`.

## Session Logged

- 2026-05-11: 5 tweets ingested (2 with full text, 2 link-only, 1 greenhandai with no content retrieved)
- Key finding: xreach returns metadata even for link-only tweets; content-not-retrieved
  tweets should still be filed with a note
