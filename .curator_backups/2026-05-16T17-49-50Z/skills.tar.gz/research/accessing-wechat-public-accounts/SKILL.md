---
name: accessing-wechat-public-accounts
description: 访问微信公众号文章的方法和已知限制
version: 1.0.0
author: Hermes Agent
license: MIT
tags: ["wechat", "weixin", "mp.weixin.qq.com", "content-access"]
metadata:
  platform: WeChat Public Accounts (微信公众号)
  limitation: "mp.weixin.qq.com has anti-bot verification that blocks browser automation"
---

# 访问微信公众号文章

## ⚠️ 必读：收到微信文章链接必须先加载此 skill

**用户明确要求：收到微信公众号链接时，必须先 `skill_view(name='accessing-wechat-public-accounts')` 再执行采集。**

用户说过 "用skills读，又忘记了吗" — 这说明本 skill 经常被忽略。
**正确流程：收到微信文章链接 → 立即加载本 skill → 执行采集。不要跳过 skill 直接用 python/curl 命令。**

## 已知的采集工具

## ✅ 可行的技术方案：wechat-article-for-ai

> Camoufox browser will be auto-downloaded on first run.
>
> **归档工作流**：`references/wechat-wiki-workflow.md` — 微信文章 → wiki 完整流程（用户明确要求：发来的文章都要归档到 llm-wiki）

### 安装步骤

```bash
# 1. 克隆工具到 agent-reach 目录
git clone https://github.com/bzd6661/wechat-article-for-ai.git ~/.agent-reach/tools/

# 2. 安装依赖
uv pip install camoufox

# 3. 确保 agent-reach 已安装
hermes skills install agent-reach --force
```

### 使用方法

```bash
# 单篇读取（推荐，避免超时）
python3 ~/.agent-reach/tools/wechat-article-for-ai/main.py "https://mp.weixin.qq.com/s/xxxx"

# 输出格式：Markdown，保存在 ~/.agent-reach/tools/output/<文章标题>/
```

### 输出路径

> ⚠️ 重要：文章保存在 `/tmp/output/<文章标题>/`（即运行工具时的 cwd 下），而不是 `~/.agent-reach/tools/...` 下。

实际路径示例：
```
/tmp/output/Obsidian 插件：Project Planner 通过多种视图管理你的计划/Obsidian 插件：Project Planner 通过多种视图管理你的计划.md
/tmp/output/最实在最现实的OPC，一个人手搓16个App.../最实在最现实的OPC....md
```

**读取已下载文章的步骤：**
```bash
# 1. 先找到文件（中文目录名在 shell 中难以直接引用）
find /tmp/output -name "*.md" -mmin -10   # 找最近下载的

# 2. 用 Python 复制（避免 shell 引号/特殊字符问题）
python3 -c "
import os, shutil
src = '/tmp/output/<文章标题>/<文件名>.md'
dst = '/home/wangsiji/projects/wsj-second-brain/Inbox/_wiki/raw/articles/<保存名>.md'
shutil.copy(src, dst)
"
```

### 已知限制

- **批量读取容易超时**：一次传多个 URL 会在 60s 内超时，务必单篇执行
- **首次使用需要微信扫码**：camoufox 会弹出浏览器窗口，需人工授权一次
- **文章标题作为目录名**：中文标题会作为文件夹名称存储

### 常见 Bug：soup.new_tag() 返回 None

**症状**：`TypeError: 'NoneType' object is not callable` 在 `parser.py:128`

**原因**：BeautifulSoup 4.14+ 搭配 lxml 解析器时，`soup.new_tag()` 在某些上下文返回 `None`

**修复**：在 `_extract_code_blocks()` 和 `_extract_media()` 函数中，将 `soup.new_tag("p")` 改为：
```python
from bs4 import BeautifulSoup as BS
_soup = BS("", "html.parser")
placeholder = _soup.new_tag("p")
```

完整 patch：
```python
# 原来：
placeholder = soup.new_tag("p")

# 改为：
from bs4 import BeautifulSoup as BS
_soup = BS("", "html.parser")
placeholder = _soup.new_tag("p")
```

所有用到 `soup.new_tag()` 的地方都需要这样替换。

## ⚠️ 常见问题

**Q: 读取时报 `TypeError: 'NoneType' object is not callable` 在 `soup.new_tag`？**
A: 这是 BeautifulSoup 4.14.3 + lxml 解析器的兼容 bug。在 `parser.py` 第 128 行附近，把 `placeholder = soup.new_tag("p")` 改为：
```python
from bs4 import BeautifulSoup as BS
_soup = BS("", "html.parser")
placeholder = _soup.new_tag("p")
```
此 bug 由 Agent 修复，后续拉取工具更新即可。

**❌ 分享链接解析错误（常见坑）**

微信分享链接（右上角→复制链接）包含动态 `poc_token` 参数：

```
https://mp.weixin.qq.com/s/WTD0TEKn0h_vjgNR1WGSxQ
↓ 实际访问时被重定向到
https://mp.weixin.qq.com/mp/wappoc_appmsgcaptcha?poc_token=HEWSAWqj7ZA7p9XBBrWFq5T1Qn2LixVBSCesqxYV&target_url=https%3A%2F%2Fmp.weixin.qq.com%2Fs%2FWTD0TEKn0h_vjgNR1WGSxQ
```

camoufox 会跟随这个重定向，但拿到的是**错误的文章内容**（演示：两个不同的分享链接都被解析成了 Harness/Claude Code 文章）。

**症状**：wechat-article-for-ai 返回的文章标题与预期不符。

**解决方案（按优先级）**：

1. **让用户提供原文文字**（最快，最准）：让用户直接在微信里长按文章→全选→复制正文发给你
2. **抓包获取真实 article_url**：在 Android 上用 mitmproxy 抓到不带 poc_token 的真实 `content_url`
3. **用 wechat-article-for-ai 的 --url 参数**：某些版本支持直接传真实 content_url 绕过重定向

**⚠️ Twitter 分享的微信链接陷阱（实测踩坑）**

用户从 Twitter 点击微信文章链接时，URL 通常带有 `?s=xx` 参数：
```
https://mp.weixin.qq.com/s/h3SVf7nyCVQqZmkc5paDzg?s=46
```

这个 `?s=46` 是 Twitter 的追踪参数，不是文章标识。camoufox 会跟随重定向，但有时会解析成**完全不同的文章**（实测：`WTD0TEKn0h_vjgNR1WGSxQ` 被解析成了 Harness + Claude Code 的文章）。

**症状**：wechat-article-for-ai 返回的标题与预期不符。

**预防**：用户发来微信文章时，先检查 URL 里是否有 `?s=` 或 `?scene=` 等 Twitter/平台追踪参数。**如果有，去掉这些参数后再传给抓取工具**：
```bash
# 提取纯净 URL
url="https://mp.weixin.qq.com/s/h3SVf7nyCVQqZmkc5paDzg?s=46"
pure_url="${url%%\?*}"  # 去掉 ? 及其后面的一切
python3 ~/.agent-reach/tools/wechat-article-for-ai/main.py "$pure_url"
```

**预防**：用户发来微信文章时，先确认是「直接链接」还是「分享链接」，分享链接优先让用户复制正文。

---

**Q: 读取时提示超时怎么办？**
A: 减少每批次的 URL 数量，务必单篇执行。

**Q: 提示"环境异常"怎么办？**
A: 说明文章无法直接抓取，让用户复制正文内容发给你。

**Q: 工具输出了但文件不存在？**
A: 工具的 cwd 决定输出位置。每次运行 `cd /tmp` 再执行，或用绝对路径 `python3 .../main.py "url" -o /tmp/output`，避免中文目录名在 shell 中引发引号/特殊字符问题。

**Q: 抓到的文章标题和预期不符？**
A: 微信公众号的短链接（如 `https://t.co/xxx`）在解析时可能被中间跳转重定向，导致拿到另一篇文章。解决方案：让用户提供文章**原始 URL**（从 mp.weixin.qq.com 复制的完整链接，不是短链接）。

### 验证成功的标志

输出日志出现类似字样表示成功：
```
正在提取标题...
正在提取作者...
正在提取发布时间...
正在提取正文...
文章保存位置：/home/user/.agent-reach/tools/output/xxxxx/xxxxx.md
```

---

## 替代方案（如果上述方法失效）

| 方式 | 操作步骤 |
|------|---------|
| **直接提供正文内容** | 用户复制文章正文（长按 → 全选 → 复制）发给你 |
| **浏览器开发者工具** | 在微信 PC 端打开文章，按 F12 在 Network 里找到 article content |

## Agent-Reach 支持的平台

Agent-Reach 支持以下平台，微信公众号**不在官方支持列表**，但可以通过 `wechat-article-for-ai` 工具实现：

- ✅ Twitter/X
- ✅ Reddit
- ✅ YouTube
- ✅ 小红书
- ✅ B站
- ✅ GitHub
- ✅ 网页抓取（普通网站）
- ⚠️ **微信公众号**（需用 wechat-article-for-ai，见上文）

### Step 1：获取文章 URL 列表

**✅ 实测有效流程（2026-05-03）：**

1. 用户分享一篇文章链接（微信文章 → 右上角三个点 → 复制链接）
2. 从链接中提取 `__biz` 参数（公众号唯一标识，base64）
3. 用 `appmsg_token` + `pass_ticket` 调用文章列表 API（offset 分页）
4. 无 token 的 API 请求返回 `ret:-3, no session`（已实测确认）

**获取 token 的可行方案（按优先级）：**

| 方案 | 操作难度 | 成功率 | 推荐度 |
|------|---------|--------|--------|
| **A. 用户登录微信公众平台后台** | 低 | 高 | ⭐⭐⭐⭐⭐ |
| **B. wxrank API** | 低 | 高 | ⭐⭐⭐⭐（2分/篇） |
| **C. Android + mitmproxy** | 中 | 高 | ⭐⭐⭐ |
| **D. iOS + mitmproxy** | 高 | ❌ 不行 | — |

**方案 A：微信公众平台后台（推荐，无需任何技术操作）**
- 用户登录 `mp.weixin.qq.com` → 内容与互动 → 群发 → 导出文章列表
- 直接导出 Excel/CSV，包含所有文章标题、链接、发布时间
- 需要公众号管理员权限

**方案 B：wxrank API**
- 第三方平台，按篇收费（约2分/篇）
- 支持按公众号批量导出文章 URL 列表
- 无需自部署，直接调用 API

**方案 C/D：mitmproxy 拦截**
- 拦截脚本：`/home/wangsiji/projects/wechat-scrape/wechat_intercept.py`
- 启动：`mitmdump -s /home/wangsiji/projects/wechat-scrape/wechat_intercept.py --set confdir=~/.mitmproxy -p 8888`
- 服务器 IP：`192.3.16.123`
- ⚠️ **Android 可以；iOS 微信有证书固定（Certificate Pinning），无法拦截 TLS 流量，切实践壁**

**❌ 已确认不可行：**
- `https://www.icloud.com/icloud-drive` 不是 WebDAV 端点（实测 404）
- iCloud Drive 无标准 WebDAV 接口，davfs2 无法挂载
- `icloud-for-linux`（snap 安装）虽然可以在 Debian 上安装，但它是 Qt GUI 应用，需要图形桌面/X11 环境，**VPS 无显示器，该方案完全不可用**
- 纯服务器端（无手机配合）无法获取微信登录态 token

**✅ iCloud for Linux 实测结论（2026-05-04）：**
- 可以安装：`sudo snap install icloud-for-linux`
- 但无法运行：`snap run icloud-for-linux` 报错 "cannot find app" 或启动后立即退出
- 原因：需要 `DISPLAY` 和完整 Qt 渲染栈，VPS 纯命令行环境不支持
- 即使有 Xvfb 也跑不完整（里面嵌了 WebEngine 控件）

### Step 2：批量下载正文

拿到 URL 列表后：
```bash
python3 ~/.agent-reach/tools/wechat-article-for-ai/main.py -f urls.txt -o ./output -v
```

批量处理建议分批执行，避免触发反爬。

## 建议

当用户请求访问微信公众号文章时，**按以下顺序操作**：

1. **检查 URL 质量**：要求用户提供 `mp.weixin.qq.com/s/...` 格式的**原始完整链接**，而非短链接（t.co/xxx）或分享卡片。短链接在解析时会跟随重定向，可能拿到完全不同的文章。

2. **用 wechat-article-for-ai 下载正文**
   ```bash
   cd /tmp
   python3 ~/.agent-reach/tools/wechat-article-for-ai/main.py "https://mp.weixin.qq.com/s/完整URL"
   ```

3. **读取输出文件**（用 Python 避免中文路径引号问题）
   ```python
   import os, shutil, glob
   # 找最近下载的 md 文件
   files = sorted(glob.glob('/tmp/output/**/[^images]*.md'), key=os.path.getmtime, reverse=True)
   print(files[0] if files else "No file found")
   ```

4. **归档到 wiki**：原始 markdown 存入 `_wiki/raw/articles/`，提炼要点写 `_wiki/concepts/`。