# 微信公众号文章 → llm-wiki 归档工作流

> 用户明确要求：发来的微信文章都要归档到 llm-wiki（Obsidian vault）。

## 完整工作流

```
用户发来微信文章链接
    ↓
1. 检查 URL 格式
   - 要求 mp.weixin.qq.com/s/... 完整链接，不要短链接
   - 短链接会被解析成其他文章
    ↓
2. 抓取正文
   cd /tmp && python3 ~/.agent-reach/tools/wechat-article-for-ai/main.py "<完整URL>"
    ↓
3. 找文件（用 Python 避免中文路径引号问题）
   python3 -c "import glob; files=glob.glob('/tmp/output/**/[^images]*.md', recursive=True); print(sorted(files, key=__import__('os').path.getmtime, reverse=True)[0])"
    ↓
4. 复制到 wiki raw 层
   python3 -c "
   import os, shutil
   src = '/tmp/output/.../文章名.md'
   dst_dir = '/home/wangsiji/projects/wsj-second-brain/Inbox/_wiki/raw/articles/'
   os.makedirs(dst_dir, exist_ok=True)
   shutil.copy(src, dst_dir + 'slug-name.md')
   "
    ↓
5. 写概念页到 _wiki/concepts/（提炼要点，不要复制原文）
    ↓
6. 更新 _wiki/index.md（+1 page）和 _wiki/log.md（append 操作记录）
```

## 注意事项

- **工具输出路径**：`/tmp/output/<中文标题>/<中文标题>.md`
- **Chinese 目录名含 `""` 引号**：直接 shell 引用会失败，必须用 Python
- **背景进程**：长时间抓取用 `terminal(background=true)`
- **抓取失败**：工具返回 "环境异常" 或内容不符时，让用户复制正文

## 概念页格式

```markdown
---
title: <主题名>
created: <今天日期>
updated: <今天日期>
type: concept
tags: [<标签1>, <标签2>]
sources: [_wiki/raw/articles/<原文件>.md]
confidence: high/medium/low
---

# <标题>

## 核心概念
【50-150字，用自己的话概括，不要复制原文】

## 对秋秋产品的启发
【如果有的话，这条内容对小程序/内容产品有什么关联】
```

## Index 更新格式

```markdown
- [[概念页标题]] — 一句话说明
```
